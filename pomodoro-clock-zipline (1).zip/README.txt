A Pen created at CodePen.io. You can find this one at http://codepen.io/nickey_vee/pen/BQaLgb.

 